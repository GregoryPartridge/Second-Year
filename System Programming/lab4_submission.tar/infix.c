#include "infix.h"

int compare_to_top_of_stack(char top_of_stack, char current_opperator){
	
	if(top_of_stack == '^')
	{
		return 1;
	}
	else if(top_of_stack == 'X' || top_of_stack == 'x' || top_of_stack == '/')
	{
		if(current_opperator == '^')
		{
			return 0;
		}
		else
		{
			return 1;
		}
	}
	else if(top_of_stack == '+' || top_of_stack == '-')
	{
		if(current_opperator == '^' || current_opperator == 'X' || current_opperator == 'x' || current_opperator == '/')
		{
			return 0;
		}
		else
		{
			return 1;
		}
	}
	else
	{
		return 0;
	}
}


double evaluate_infix_expression(char ** argv, int array_size) {
	char ** output_string = malloc(sizeof(double)* array_size);
	int current_item_on_stack;
	int string_lenght = 0;

	int done = 0;				//boolean hotfix

	struct double_stack * myStack = double_stack_new(array_size);
	for(int count = 0; count < array_size; count++)
	{
		if(argv[count][0] == '(')
		{
			double_stack_push(myStack, count);
		}
		else if(argv[count][0] == ')')
		{
			done = 0;
			while(done == 0)
			{
				current_item_on_stack = double_stack_pop(myStack);
				if(argv[current_item_on_stack][0] != '(')
				{
					output_string[string_lenght++] = argv[current_item_on_stack];
				}
				else
				{
					done = 1;
				}	
			}
		}
		else if((argv[count][0]=='+' || argv[count][0]=='-' || argv[count][0]=='x' || argv[count][0]=='X' || argv[count][0]=='/' || argv[count][0]=='^') && strlen(argv[count]) == 1)
		{

			while(compare_to_top_of_stack(argv[(int)myStack->items[myStack->top - 1]][0], argv[count][0]))
			{	
				output_string[string_lenght++] = argv[(int)double_stack_pop(myStack)];
			}
			double_stack_push(myStack, count);
		}
		else
		{
			output_string[string_lenght++] = argv[count];
		}

	}

	while(myStack->top)
	{
		current_item_on_stack = double_stack_pop(myStack);
		output_string[string_lenght++] = argv[current_item_on_stack];
	}
	

	return evaluate_postfix_expression(output_string , string_lenght);
}
