#include "postfix.h"

// all the opperator functions

void addition(struct double_stack * myStack)
{
	double first_number = double_stack_pop(myStack);
	double second_number = double_stack_pop(myStack);
	double new_number = first_number + second_number;
	double_stack_push(myStack, new_number);
}

void subtraction(struct double_stack * myStack)
{
	double first_number = double_stack_pop(myStack);
	double second_number = double_stack_pop(myStack);
	double new_number = second_number - first_number ;
	double_stack_push(myStack, new_number);
}

void multiplication(struct double_stack * myStack)
{
	double first_number = double_stack_pop(myStack);
	double second_number = double_stack_pop(myStack);
	double new_number = first_number * second_number;
	double_stack_push(myStack, new_number);
}

void division(struct double_stack * myStack)
{
	double first_number = double_stack_pop(myStack);
	double second_number = double_stack_pop(myStack);
	double new_number = second_number / first_number ;
	double_stack_push(myStack, new_number);
}

void power_of(struct double_stack * myStack)
{
	double first_number = double_stack_pop(myStack);
	double second_number = double_stack_pop(myStack);
	double new_number = pow(second_number, first_number);
	double_stack_push(myStack, new_number);
}

double evaluate_postfix_expression(char ** argv, int array_size)
{
	int current_int;
	struct double_stack * myStack = double_stack_new(array_size);
	for(int count = 0; count < array_size; count++)
	{
		current_int = argv[count][0];
		switch (current_int)
		{
			case '+': addition(myStack);
				  break;
			case '-':
				  if (strlen(argv[count]) == 1) {
					  subtraction(myStack);
				  } else {
					  double_stack_push(myStack, atof(argv[count]));
				  }
				  break;
			case 'x':
			case 'X': multiplication(myStack);
				  break;
			case '/': division(myStack);
				  break;
			case '^': power_of(myStack);
				  break;
			default:
				  double_stack_push(myStack, atof(argv[count]));
				  break;
		}
	}	
	return double_stack_pop(myStack);
}
